insert into :table: (server_id, name, type) values (:server_id:, :name:, :type:)
